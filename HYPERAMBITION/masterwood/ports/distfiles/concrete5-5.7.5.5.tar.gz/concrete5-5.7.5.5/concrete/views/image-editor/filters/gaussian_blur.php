<div class="row form-horizontal">
    <div class="form-group col-sm-10">
        <label class="control-label col-sm-4"><?php echo t('Radius') ?></label>
        <div class="col-sm-8 slider-container">
            <div class="radius-slider"></div>
        </div>
    </div>
    <div class="col-sm-2">
        <span class="radius-percent">5</span>
    </div>
</div>

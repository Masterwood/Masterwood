<?php defined('C5_EXECUTE') or die("Access Denied."); ?>
<h1><?php echo t('Unexpected User Error')?></h1>

<?php echo t('Something about your user account has changed. You have been logged out. Please refresh this page to continue.')?>

<Br/><br/>
<a href="<?php echo DIR_REL?>/"><?php echo t('Back to Home')?></a>.
<?php
defined('C5_EXECUTE') or die("Access Denied.");
?>

<div class="ccm-ui">

<?php Loader::element('group/search', array('controller' => $searchController, 'selectMode' => true))?>

</div>
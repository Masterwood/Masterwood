<?php
defined('C5_EXECUTE') or die("Access Denied.");
Loader::element('permission/details/block', array('b' => $b, 'rcID' => $rcID));

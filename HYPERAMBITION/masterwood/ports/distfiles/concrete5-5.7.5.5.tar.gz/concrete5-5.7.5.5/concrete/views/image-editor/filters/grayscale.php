<?php echo t('Convert image to grayscale') ?>

<?php echo t('Remove all filters'); ?>

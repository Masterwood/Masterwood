<?php
defined('C5_EXECUTE') or die("Access Denied.");
Loader::element('permission/lists/block', array('b' => $b, 'rcID' => $rcID));

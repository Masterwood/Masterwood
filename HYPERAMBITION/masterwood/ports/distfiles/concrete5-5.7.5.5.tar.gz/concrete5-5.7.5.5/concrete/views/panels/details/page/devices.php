<div class="ccm-panel-detail-devices-container"></div>
<div class="ccm-panel-detail-devices-actions ccm-panel-detail-form-actions dialog-buttons">
    <div class="btn-group pull-left ccm-device-orientation">
        <button class="pull-left btn btn-default ccm-device-portrait" type="button"><i class="fa fa-mobile"></i></button>
        <button class="pull-left btn btn-default ccm-device-landscape active" type="button"><i class="fa fa-mobile fa-rotate-90"></i></button>
    </div>
    <button class="pull-right btn btn-default ccm-panel-detail-device-exit" type="button"><?php echo t('Exit Preview')?></button>
</div>

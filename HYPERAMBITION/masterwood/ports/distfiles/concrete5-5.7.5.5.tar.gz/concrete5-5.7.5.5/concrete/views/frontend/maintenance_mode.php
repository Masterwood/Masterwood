<?php defined('C5_EXECUTE') or die("Access Denied."); ?>

<h1><?php echo t('Coming Back Soon')?></h1>

<?php echo t('This site is currently down for maintenance.')?>

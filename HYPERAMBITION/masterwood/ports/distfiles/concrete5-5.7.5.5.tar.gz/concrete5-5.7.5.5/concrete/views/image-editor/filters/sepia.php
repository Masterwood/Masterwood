<?php echo t('Apply a sepia tone') ?>

<?php
defined('C5_EXECUTE') or die("Access Denied.");
Loader::element('help/dialog/introduction');
?>
<?php
defined('C5_EXECUTE') or die("Access Denied.");

// Legacy.
Redirect::to('/ccm/system/upgrade')->send();
exit;
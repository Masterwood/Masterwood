<?php
namespace Concrete\Core\Support\Facade;

class Cookie extends Facade
{

    public static function getFacadeAccessor()
    {
        return 'cookie';
    }

}

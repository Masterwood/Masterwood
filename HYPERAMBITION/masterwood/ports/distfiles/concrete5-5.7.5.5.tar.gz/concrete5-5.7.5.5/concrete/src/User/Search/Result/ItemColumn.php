<?php
namespace Concrete\Core\User\Search\Result;
use \Concrete\Core\Search\Result\ItemColumn as SearchResultItemColumn;
class ItemColumn extends SearchResultItemColumn {



}

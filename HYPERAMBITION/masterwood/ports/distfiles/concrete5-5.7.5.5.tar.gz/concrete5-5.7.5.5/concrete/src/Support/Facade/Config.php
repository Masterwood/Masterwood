<?php
namespace Concrete\Core\Support\Facade;

class Config extends Facade {

    public static function getFacadeAccessor()
    {
        return "config";
    }

}

<?php
namespace Concrete\Core\User\Search\Result;
use \Concrete\Core\Search\Result\Column as SearchResultColumn;
class Column extends SearchResultColumn {


}

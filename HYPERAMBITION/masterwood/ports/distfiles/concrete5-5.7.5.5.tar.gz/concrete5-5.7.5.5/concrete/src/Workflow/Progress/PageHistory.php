<?php
namespace Concrete\Core\Workflow\Progress;
use Loader;
class PageHistory extends History {

}

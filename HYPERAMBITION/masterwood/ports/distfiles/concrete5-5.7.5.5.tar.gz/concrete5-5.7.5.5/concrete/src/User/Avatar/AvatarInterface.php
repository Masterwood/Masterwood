<?php
namespace Concrete\Core\User\Avatar;

interface AvatarInterface
{

    public function output();
    public function getPath();

}
